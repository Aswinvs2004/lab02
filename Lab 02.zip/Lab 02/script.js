const prompt = require('prompt');

// Start the prompt for user input
prompt.start();

// Function to decide the winner
function decideWinner(playerChoice, aiChoice) {
    if (playerChoice === aiChoice) {
        return "It's a tie!";
    }
    if (
        (playerChoice === 'ROCK' && aiChoice === 'SCISSORS') ||
        (playerChoice === 'SCISSORS' && aiChoice === 'PAPER') ||
        (playerChoice === 'PAPER' && aiChoice === 'ROCK')
    ) {
        return "You Win!";
    }
    return "Computer Wins!";
}

// Prompt user for their choice
prompt.get(['choice'], function (error, input) {
    if (error) {
        console.error(error);
        return;
    }

    // Get the player's choice and convert it to uppercase
    const playerChoice = input.choice.toUpperCase();

    // Validate user input
    if (!['ROCK', 'PAPER', 'SCISSORS'].includes(playerChoice)) {
        console.log("Please choose ROCK, PAPER, or SCISSORS.");
        return;
    }

    // Randomly determine the computer's choice
    const randomValue = Math.random();
    let aiChoice;

    if (randomValue < 0.34) {
        aiChoice = 'PAPER';
    } else if (randomValue < 0.67) {
        aiChoice = 'SCISSORS';
    } else {
        aiChoice = 'ROCK';
    }

    // Display the choices
    console.log(`Your choice: ${playerChoice}`);
    console.log(`Computer's choice: ${aiChoice}`);

    // Determine and print the outcome
    const result = decideWinner(playerChoice, aiChoice);
    console.log(result);
});
